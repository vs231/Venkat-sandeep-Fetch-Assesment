package com.example.receiptprocessor.model;

public class PointsResponse {
    private int points;

    public PointsResponse(int points) {
        this.points = points;
    }

    // Getter
    public int getPoints() {
        return points;
    }
}

package com.example.receiptprocessor.model;

public class ReceiptResponse {
    private String id;

    public ReceiptResponse(String id) {
        this.id = id;
    }

    // Getter
    public String getId() {
        return id;
    }
}

package com.example.receiptprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceiptprocessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
